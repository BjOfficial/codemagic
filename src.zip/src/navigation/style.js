import { StyleSheet } from 'react-native';
const style = StyleSheet.create({
	dot: {
		alignSelf: 'center',
		color: '#f3a03c',
		fontSize: 8,
	},
});

export default style;

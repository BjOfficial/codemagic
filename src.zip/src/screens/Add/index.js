import React from 'react';
import * as RN from 'react-native';

const Add = () => {
	return (
		<RN.View>
			<RN.Text>{'InviteFriends'}</RN.Text>
		</RN.View>
	);
};

export default Add;

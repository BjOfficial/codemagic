import React from 'react';
import * as RN from 'react-native';

const MyAssets = () => {
	return (
		<RN.View>
			<RN.Text>{'MyAssetss'}</RN.Text>
		</RN.View>
	);
};

export default MyAssets;

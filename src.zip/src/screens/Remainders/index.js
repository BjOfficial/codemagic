import React from 'react';
import * as RN from 'react-native';

const Remainders = () => {
	return (
		<RN.View>
			<RN.Text>{'Remainders'}</RN.Text>
		</RN.View>
	);
};

export default Remainders;
